﻿/**************
 *  Only for functions, methods and classes
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperPlus.components
{
    class Lib
    {
    }
}
