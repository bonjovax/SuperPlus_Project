﻿/**************
 *  Use for Global, Constants and other necessary variables
 *
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperPlus.components
{
    class Constplus
    {
    }
}
