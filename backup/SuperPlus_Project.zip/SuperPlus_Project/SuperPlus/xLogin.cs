﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraBars;

namespace SuperPlus
{
    public partial class xLogin : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public xLogin()
        {
            InitializeComponent();
        }
    }
}